<?php
session_start();
require_once 'db.php';
require_once 'csrf.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login_input = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($login_input) || empty($password)) {
        $error = "يرجى إدخال اسم المستخدم/البريد الإلكتروني وكلمة المرور.";
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username OR email = :email LIMIT 1");
        $stmt->execute([
            'username' => $login_input,
            'email' => $login_input
        ]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            session_regenerate_id(true);
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            header("Location: view_students.php");
            exit;
        } else {
            $error = "بيانات الدخول غير صحيحة.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل الدخول - Student Registration System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body class="d-flex align-items-center justify-content-center">

    <div class="container" style="max-width: 450px;">
        <div class="custom-card text-center">
            
            <div id="alertBox">
                <?php if (isset($_GET['registered'])): ?>
                    <div class="alert alert-success text-center py-2">تم إنشاء الحساب بنجاح! يمكنك تسجيل الدخول الآن.</div>
                <?php endif; ?>
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger text-center py-2"><?= htmlspecialchars($error) ?></div>
                <?php endif; ?>
            </div>
            
            <form id="loginForm" method="POST" action="login.php" novalidate>
                <?= csrf_field() ?>
                <div class="input-group mb-3">
                    <span class="input-group-text bg-white border-0 text-muted"><i class="fa-regular fa-user"></i></span>
                    <input type="text" id="username" name="username" class="form-control form-control-custom" placeholder="اسم المستخدم / البريد الإلكتروني" value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required>
                </div>

                <div class="input-group mb-4">
                    <span class="input-group-text bg-white border-0 text-muted"><i class="fa-solid fa-key"></i></span>
                    <input type="password" id="password" name="password" class="form-control form-control-custom" placeholder="كلمة المرور" required>
                </div>

                <button type="submit" class="btn btn-teal w-100 text-uppercase">LOGIN</button>
            </form>

            <div class="mt-4">
                <a href="#" class="teal-link small">نسيت كلمة المرور؟</a>
            </div>
            <div class="mt-2">
                <span class="text-light small">ليس لديك حساب؟</span> 
                <a href="register.php" class="teal-link small">إنشاء حساب جديد</a>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="main.js"></script>
</body>
</html>