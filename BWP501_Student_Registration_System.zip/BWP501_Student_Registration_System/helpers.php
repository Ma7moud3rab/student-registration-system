<?php
function e($value): string {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}
function upload_profile_picture(string $field = 'profile_picture'): ?string {
    if (empty($_FILES[$field]) || $_FILES[$field]['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }
    $file = $_FILES[$field];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException('حدث خطأ أثناء رفع الصورة.');
    }
    if ($file['size'] > 2 * 1024 * 1024) {
        throw new RuntimeException('حجم الصورة يجب ألا يتجاوز 2 ميغابايت.');
    }
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);
    $allowed = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
        'image/gif' => 'gif'
    ];
    if (!isset($allowed[$mime])) {
        throw new RuntimeException('نوع الصورة غير مدعوم. استخدم JPG أو PNG أو WEBP أو GIF.');
    }
    $dir = __DIR__ . '/uploads';
    if (!is_dir($dir) && !mkdir($dir, 0755, true)) {
        throw new RuntimeException('تعذر تجهيز مجلد الصور.');
    }
    $filename = bin2hex(random_bytes(16)) . '.' . $allowed[$mime];
    if (!move_uploaded_file($file['tmp_name'], $dir . '/' . $filename)) {
        throw new RuntimeException('تعذر حفظ الصورة المرفوعة.');
    }
    return $filename;
}
function remove_profile_picture(?string $filename): void {
    if (!$filename) return;
    $safe = basename($filename);
    $path = __DIR__ . '/uploads/' . $safe;
    if (is_file($path)) @unlink($path);
}
