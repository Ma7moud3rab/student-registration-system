<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>الصفحة الرئيسية - نظام إدارة الطلاب</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<?php require_once "auth_check.php"; ?>
<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom">
        <div class="container">
            <a class="navbar-brand text-teal fw-bold" href="index.php">
                <i class="fa-solid fa-graduation-cap me-2"></i>نظام الطلاب
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link active" href="index.php">الرئيسية</a></li>
                    <li class="nav-item"><a class="nav-link" href="view_students.php">عرض الطلاب</a></li>
                    <li class="nav-item"><a class="nav-link" href="add_student.php">إضافة طالب</a></li>
                    <li class="nav-item"><a class="nav-link text-danger" href="logout.php">تسجيل الخروج</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container my-5">
        <div class="custom-card text-center p-5">
            <h1 class="display-5 fw-bold mb-3">أهلاً بك في نظام إدارة الطلاب</h1>
            <p class="lead mb-4">نظام متكامل لتسجيل وإدارة بيانات الطلاب بسهولة وفعالية.</p>
            <div class="d-flex justify-content-center gap-3">
                <a href="add_student.php" class="btn btn-teal px-4"><i class="fa-solid fa-user-plus me-2"></i>إضافة طالب جديد</a>
                <a href="view_students.php" class="btn btn-outline-light px-4"><i class="fa-solid fa-list me-2"></i>عرض كافة الطلاب</a>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>