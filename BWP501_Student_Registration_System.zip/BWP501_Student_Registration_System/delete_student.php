<?php
require_once 'auth_check.php';
require_once 'db.php';
require_once 'csrf.php';
require_once 'helpers.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('طريقة الطلب غير مسموحة.');
}
verify_csrf();
$id = (int)($_POST['id'] ?? 0);
$stmt = $pdo->prepare('SELECT profile_picture FROM students WHERE id = ?');
$stmt->execute([$id]);
$student = $stmt->fetch();
if ($student) {
    $delete = $pdo->prepare('DELETE FROM students WHERE id = ?');
    $delete->execute([$id]);
    remove_profile_picture($student['profile_picture']);
}
header('Location: view_students.php?message=' . urlencode('تم تنفيذ عملية الحذف.'));
exit;
