<?php
require_once 'auth_check.php';
require_once 'db.php';
require_once 'csrf.php';
require_once 'helpers.php';
$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$stmt = $pdo->prepare('SELECT * FROM students WHERE id = ?');
$stmt->execute([$id]);
$student = $stmt->fetch();
if (!$student) { http_response_code(404); exit('الطالب غير موجود. <a href="view_students.php">العودة</a>'); }
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        verify_csrf();
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $address = trim($_POST['address'] ?? '');
        if ($name === '' || $email === '' || $phone === '' || $address === '') throw new RuntimeException('يرجى تعبئة جميع الحقول المطلوبة.');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) throw new RuntimeException('صيغة البريد الإلكتروني غير صحيحة.');
        $newPicture = upload_profile_picture();
        $picture = $newPicture ?: $student['profile_picture'];
        $update = $pdo->prepare('UPDATE students SET name=?,email=?,phone=?,address=?,profile_picture=? WHERE id=?');
        $update->execute([$name,$email,$phone,$address,$picture,$id]);
        if ($newPicture) remove_profile_picture($student['profile_picture']);
        header('Location: view_students.php?message=' . urlencode('تم تحديث بيانات الطالب بنجاح.'));
        exit;
    } catch (Throwable $ex) { $error = $ex->getMessage(); }
    $student = array_merge($student, ['name'=>$name ?? $student['name'], 'email'=>$email ?? $student['email'], 'phone'=>$phone ?? $student['phone'], 'address'=>$address ?? $student['address']]);
}
?>
<!DOCTYPE html><html lang="ar" dir="rtl"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>تعديل بيانات طالب</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet"><link rel="stylesheet" href="style.css"></head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark navbar-custom"><div class="container">
<a class="navbar-brand fw-bold" href="index.php"><i class="fa-solid fa-graduation-cap me-2"></i>نظام الطلاب</a>
<div class="navbar-nav ms-auto"><a class="nav-link" href="index.php">الرئيسية</a><a class="nav-link" href="view_students.php">عرض الطلاب</a></div></div></nav>
<div class="container my-5" style="max-width:650px"><div class="custom-card">
<h3 class="mb-4 text-center"><i class="fa-solid fa-user-pen me-2"></i>تعديل بيانات الطالب</h3>
<?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
<form id="updateStudentForm" action="update_student.php?id=<?= $id ?>" method="POST" enctype="multipart/form-data">
<?= csrf_field() ?><input type="hidden" name="id" value="<?= $id ?>">
<div class="mb-3"><label class="form-label">الاسم الكامل</label><input type="text" name="name" id="student_name" class="form-control form-control-custom" value="<?= e($student['name']) ?>" required></div>
<div class="mb-3"><label class="form-label">البريد الإلكتروني</label><input type="email" name="email" id="student_email" class="form-control form-control-custom" value="<?= e($student['email']) ?>" required></div>
<div class="mb-3"><label class="form-label">رقم الهاتف</label><input type="text" name="phone" id="student_phone" class="form-control form-control-custom" value="<?= e($student['phone']) ?>" required></div>
<div class="mb-3"><label class="form-label">العنوان</label><textarea name="address" id="student_address" class="form-control form-control-custom" rows="3" required><?= e($student['address']) ?></textarea></div>
<div class="mb-3 text-center"><label class="form-label d-block text-start">الصورة الشخصية الحالية</label>
<img src="<?= $student['profile_picture'] ? 'uploads/' . rawurlencode($student['profile_picture']) : 'uploads/default.svg' ?>" class="rounded-circle mb-2" width="70" height="70" style="object-fit:cover" alt="Current Profile"></div>
<div class="mb-4"><label class="form-label">تحديث الصورة الشخصية (اختياري)</label><input type="file" name="profile_picture" id="profile_picture" class="form-control form-control-custom" accept="image/jpeg,image/png,image/webp,image/gif"></div>
<div class="d-flex justify-content-between"><a href="view_students.php" class="btn btn-outline-light">إلغاء</a><button type="submit" class="btn btn-teal px-4">حفظ التعديلات</button></div>
</form></div></div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script><script src="main.js"></script></body></html>
