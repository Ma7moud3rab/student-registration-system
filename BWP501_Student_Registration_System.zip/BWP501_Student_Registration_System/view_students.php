<?php
require_once 'auth_check.php';
require_once 'db.php';
require_once 'csrf.php';
require_once 'helpers.php';

$search = trim($_GET['search'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 10;
$where = '';
$params = [];
if ($search !== '') {
    $where = ' WHERE name LIKE :q OR email LIKE :q OR phone LIKE :q';
    $params['q'] = '%' . $search . '%';
}
$countStmt = $pdo->prepare('SELECT COUNT(*) FROM students' . $where);
$countStmt->execute($params);
$total = (int)$countStmt->fetchColumn();
$totalPages = max(1, (int)ceil($total / $perPage));
$page = min($page, $totalPages);
$offset = ($page - 1) * $perPage;
$sql = 'SELECT * FROM students' . $where . ' ORDER BY id DESC LIMIT :limit OFFSET :offset';
$stmt = $pdo->prepare($sql);
foreach ($params as $key => $value) $stmt->bindValue(':' . $key, $value, PDO::PARAM_STR);
$stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$students = $stmt->fetchAll();
function page_url($p, $search) {
    return '?' . http_build_query(['search' => $search, 'page' => $p]);
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>قائمة الطلاب</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container my-5">
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <h2><i class="fa-solid fa-users me-2"></i>قائمة الطلاب</h2>
        <div class="d-flex gap-2">
            <a href="index.php" class="btn btn-outline-light">الرئيسية</a>
            <a href="add_student.php" class="btn btn-teal"><i class="fa-solid fa-plus me-1"></i> إضافة طالب</a>
        </div>
    </div>
    <?php if (isset($_GET['message'])): ?><div class="alert alert-success"><?= e($_GET['message']) ?></div><?php endif; ?>
    <form class="row mb-4" method="GET" action="view_students.php">
        <div class="col-md-6">
            <div class="input-group">
                <input type="search" name="search" id="searchInput" value="<?= e($search) ?>" class="form-control form-control-custom" placeholder="البحث باسم الطالب، البريد، أو رقم الهاتف...">
                <button class="btn btn-teal" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
                <?php if ($search !== ''): ?><a class="btn btn-outline-light" href="view_students.php">مسح</a><?php endif; ?>
            </div>
        </div>
    </form>
    <div class="table-responsive">
        <table class="table table-custom align-middle text-center">
            <thead><tr><th>#</th><th>الصورة</th><th>الاسم</th><th>البريد الإلكتروني</th><th>الهاتف</th><th>العنوان</th><th>الإجراءات</th></tr></thead>
            <tbody id="studentTableBody">
            <?php if (!$students): ?>
                <tr><td colspan="7" class="py-4">لا توجد سجلات طلاب مطابقة.</td></tr>
            <?php else: foreach ($students as $index => $student): ?>
                <tr>
                    <td><?= $offset + $index + 1 ?></td>
                    <td><img src="<?= $student['profile_picture'] ? 'uploads/' . rawurlencode($student['profile_picture']) : 'uploads/default.svg' ?>" class="rounded-circle" width="40" height="40" alt="Profile" style="object-fit:cover"></td>
                    <td><?= e($student['name']) ?></td><td><?= e($student['email']) ?></td>
                    <td><?= e($student['phone']) ?></td><td><?= e($student['address']) ?></td>
                    <td class="text-nowrap">
                        <a href="update_student.php?id=<?= (int)$student['id'] ?>" class="btn btn-sm btn-outline-info me-1" aria-label="تعديل"><i class="fa-solid fa-pen"></i></a>
                        <button type="button" onclick="confirmDelete(<?= (int)$student['id'] ?>)" class="btn btn-sm btn-outline-danger" aria-label="حذف"><i class="fa-solid fa-trash"></i></button>
                    </td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
    <?php if ($totalPages > 1): ?>
    <nav class="mt-4" aria-label="Pagination"><ul class="pagination justify-content-center flex-wrap">
        <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>"><a class="page-link" href="<?= e(page_url(max(1,$page-1),$search)) ?>">السابق</a></li>
        <?php for ($p=1; $p <= $totalPages; $p++): ?>
        <li class="page-item <?= $p === $page ? 'active' : '' ?>"><a class="page-link" href="<?= e(page_url($p,$search)) ?>"><?= $p ?></a></li>
        <?php endfor; ?>
        <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>"><a class="page-link" href="<?= e(page_url(min($totalPages,$page+1),$search)) ?>">التالي</a></li>
    </ul></nav>
    <?php endif; ?>
    <p class="text-center small text-light">عدد النتائج: <?= $total ?> — الصفحة <?= $page ?> من <?= $totalPages ?></p>
</div>

<div class="modal fade" id="deleteModal" tabindex="-1">
 <div class="modal-dialog modal-dialog-centered"><div class="modal-content bg-dark text-white border-secondary">
  <div class="modal-header border-secondary"><h5 class="modal-title">تأكيد الحذف</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
  <div class="modal-body">هل أنت متأكد من رغبتك في حذف هذا الطالب؟ لا يمكن التراجع عن هذه الخطوة.</div>
  <div class="modal-footer border-secondary">
   <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
   <form id="deleteForm" method="POST" action="delete_student.php"><?= csrf_field() ?><input type="hidden" name="id" id="deleteStudentId"><button class="btn btn-danger" type="submit">حذف</button></form>
  </div>
 </div></div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script><script src="main.js"></script>
</body></html>
