<?php
require_once 'auth_check.php';
require_once 'db.php';
require_once 'csrf.php';
require_once 'helpers.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json; charset=utf-8');
    try {
        verify_csrf();
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $address = trim($_POST['address'] ?? '');
        if ($name === '' || $email === '' || $phone === '' || $address === '') {
            throw new RuntimeException('يرجى تعبئة جميع الحقول المطلوبة.');
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new RuntimeException('صيغة البريد الإلكتروني غير صحيحة.');
        }
        $picture = upload_profile_picture();
        $stmt = $pdo->prepare('INSERT INTO students (name,email,phone,address,profile_picture) VALUES (?,?,?,?,?)');
        $stmt->execute([$name, $email, $phone, $address, $picture]);
        echo json_encode(['status' => 'success', 'message' => 'تمت إضافة الطالب بنجاح.'], JSON_UNESCAPED_UNICODE);
    } catch (Throwable $ex) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => $ex->getMessage()], JSON_UNESCAPED_UNICODE);
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إضافة طالب جديد</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<?php require_once "auth_check.php"; require_once "csrf.php"; ?>
<body>

    <div class="container my-5" style="max-width: 650px;">
        <div class="custom-card">
            <h3 class="mb-4 text-center"><i class="fa-solid fa-user-plus me-2"></i>إضافة طالب جديد</h3>
            
            <div id="ajaxAlert"></div>

            <form id="addStudentForm" action="add_student.php" method="POST" enctype="multipart/form-data">
                <?= csrf_field() ?>
                <div class="mb-3">
                    <label class="form-label">الاسم الكامل</label>
                    <input type="text" name="name" id="student_name" class="form-control form-control-custom" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">البريد الإلكتروني</label>
                    <input type="email" name="email" id="student_email" class="form-control form-control-custom" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">رقم الهاتف</label>
                    <input type="text" name="phone" id="student_phone" class="form-control form-control-custom" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">العنوان</label>
                    <textarea name="address" id="student_address" class="form-control form-control-custom" rows="3" required></textarea>
                </div>
                <div class="mb-4">
                    <label class="form-label">الصورة الشخصية (اختياري)</label>
                    <input type="file" name="profile_picture" id="profile_picture" class="form-control form-control-custom" accept="image/*">
                </div>

                <div class="d-flex justify-content-between">
                    <a href="view_students.php" class="btn btn-outline-light">إلغاء</a>
                    <button type="submit" class="btn btn-teal px-4">حفظ البيانات</button>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="main.js"></script>
</body>
</html>