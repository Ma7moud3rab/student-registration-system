document.addEventListener("DOMContentLoaded", () => {
    const addForm = document.getElementById("addStudentForm");
    if (addForm) {
        addForm.addEventListener("submit", async (event) => {
            event.preventDefault();
            const alertBox = document.getElementById("ajaxAlert");
            const email = document.getElementById("student_email")?.value.trim() || "";
            if (!validateEmail(email)) {
                showAlert(alertBox, "يرجى إدخال بريد إلكتروني صحيح.", "danger");
                return;
            }
            const submit = addForm.querySelector('[type="submit"]');
            if (submit) submit.disabled = true;
            try {
                const response = await fetch(addForm.action, {
                    method: "POST",
                    body: new FormData(addForm),
                    headers: { "X-Requested-With": "XMLHttpRequest", "Accept": "application/json" }
                });
                const data = await response.json();
                if (!response.ok || data.status !== "success") throw new Error(data.message || "تعذرت إضافة الطالب.");
                showAlert(alertBox, data.message || "تمت إضافة الطالب بنجاح!", "success");
                addForm.reset();
            } catch (error) {
                showAlert(alertBox, error.message || "حدث خطأ في الاتصال بالخادم.", "danger");
            } finally {
                if (submit) submit.disabled = false;
            }
        });
    }

    const registerForm = document.getElementById("registerForm");
    if (registerForm) {
        registerForm.addEventListener("submit", (event) => {
            const pass = document.getElementById("reg_password")?.value;
            const confirm = document.getElementById("reg_confirm_password")?.value;
            if (pass !== confirm) {
                event.preventDefault();
                showAlert(document.getElementById("alertBox"), "كلمتا المرور غير متطابقتين!", "danger");
            }
        });
    }
});

function validateEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}
function showAlert(element, message, type) {
    if (!element) return;
    const alert = document.createElement("div");
    alert.className = `alert alert-${type} alert-dismissible fade show`;
    alert.setAttribute("role", "alert");
    alert.append(document.createTextNode(message));
    const close = document.createElement("button");
    close.type = "button";
    close.className = "btn-close";
    close.setAttribute("data-bs-dismiss", "alert");
    close.setAttribute("aria-label", "Close");
    alert.append(close);
    element.replaceChildren(alert);
}
function confirmDelete(studentId) {
    const input = document.getElementById("deleteStudentId");
    const modalElement = document.getElementById("deleteModal");
    if (!input || !modalElement || !window.bootstrap) return;
    input.value = String(studentId);
    bootstrap.Modal.getOrCreateInstance(modalElement).show();
}
