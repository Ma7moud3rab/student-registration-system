<?php
session_start();
require_once 'db.php';
require_once 'csrf.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if (empty($username) || empty($email) || empty($password) || empty($confirm_password)) {
        $error = "جميع الحقول مطلوبة.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "صيغة البريد الإلكتروني غير صحيحة.";
    } elseif ($password !== $confirm_password) {
        $error = "كلمتا المرور غير متطابقتين.";
    } else {
        // التحقق من عدم وجود حساب مسبق بنفس الاسم أو الإيميل
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = :username OR email = :email");
        $stmt->execute(['username' => $username, 'email' => $email]);

        if ($stmt->fetch()) {
            $error = "اسم المستخدم أو البريد الإلكتروني مسجل مسبقاً.";
        } else {
            // تشفير كلمة المرور وحفظ المستخدم في قاعدة البيانات
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $insert = $pdo->prepare("INSERT INTO users (username, email, password) VALUES (:username, :email, :password)");
            $insert->execute([
                'username' => $username,
                'email' => $email,
                'password' => $hashed_password
            ]);

            header("Location: login.php?registered=1");
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إنشاء حساب - Student Registration System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body class="d-flex align-items-center justify-content-center">

    <div class="container" style="max-width: 500px;">
        <div class="custom-card">
            <h3 class="text-center mb-4 text-white">إنشاء حساب جديد</h3>
            
            <div id="alertBox">
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger text-center py-2"><?= htmlspecialchars($error) ?></div>
                <?php endif; ?>
            </div>
            
            <form id="registerForm" action="register.php" method="POST" novalidate>
                <?= csrf_field() ?>
                <div class="mb-3">
                    <input type="text" id="reg_username" name="username" class="form-control form-control-custom" placeholder="اسم المستخدم" value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required>
                </div>
                <div class="mb-3">
                    <input type="email" id="reg_email" name="email" class="form-control form-control-custom" placeholder="البريد الإلكتروني" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
                </div>
                <div class="mb-3">
                    <input type="password" id="reg_password" name="password" class="form-control form-control-custom" placeholder="كلمة المرور" required>
                </div>
                <div class="mb-4">
                    <input type="password" id="reg_confirm_password" name="confirm_password" class="form-control form-control-custom" placeholder="تأكيد كلمة المرور" required>
                </div>

                <button type="submit" class="btn btn-teal w-100 text-uppercase">تسجيل الحساب</button>
            </form>

            <div class="mt-3 text-center">
                <span class="text-light small">لديك حساب بالفعل؟</span> 
                <a href="login.php" class="teal-link small">تسجيل الدخول</a>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="main.js"></script>
</body>
</html>